package com.example.lr4;

public class Square2 extends Rectangle2 {
}
