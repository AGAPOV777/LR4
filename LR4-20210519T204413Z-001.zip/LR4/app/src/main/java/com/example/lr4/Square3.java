package com.example.lr4;

public class Square3 extends Shape3 {

    private double side;

    public Square3(){
        side = 4.3;
    }

    public Square3(double side){
        this.side = side;
    }

    public Square3(double side, String color, boolean filled){
        super(color, filled);
        this.side = side;
    }

    public double getSide(){
        return this.side = side;
    }

    public void setSide(double side){
        this.side = side;
    }

    public void setWidth(double side){
        this.side = side;
    }

    public void setLength(double side){
        this.side = side;
    }

    @Override
    public double getArea(){
     return side * side;
    }

    public String toString(){
        return "Квадрат цвета: " + getColor() + ", длиной: " + getSide() + ", шириной: "+ getSide() + ", заполненна:  " + isFilled();
    }
}
