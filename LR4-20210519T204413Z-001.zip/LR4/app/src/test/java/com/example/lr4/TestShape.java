package com.example.lr4;

import org.junit.Test;

public class TestShape {
    @Test
    public void test() {


        Shape s1 = new Rectangle("Red", 6, 12);
        Shape s2 = new Triangle("Green", 10, 6);

        System.out.println(s1);
        System.out.println(s2);

    }
}

