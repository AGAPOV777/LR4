package com.example.lr4;

import org.junit.Test;


public class TestShape2 {
    @Test
    public void TestShape(){

        Shape2 s1 = new Shape2();
        System.out.println("S1 = " + s1);

        Circle2 c1 = new Circle2();
        System.out.println("C1 = " + c1);

        Rectangle2 r1 = new Rectangle2();
        System.out.println("R1: " + r1);
    }
}


